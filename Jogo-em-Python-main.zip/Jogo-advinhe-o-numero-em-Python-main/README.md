# Jogo-advinhe-o-numero-em-Python
Jogo feito em Python, linguagem na qual estou aprimorando meus conhecimentos.
Este game foi feito usando estruturas de repetição, operadores lógicos e estruturas de decisão.
